## 2025-12-30
- Added `make test-local` target for pyenv-aware SAM local build and `/health` smoke test.
